import pip 
pip.main(['install','wikipedia'])